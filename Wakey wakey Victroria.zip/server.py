import socket
import ssl
import threading
import os
import zipfile
from cryptography.fernet import Fernet
import logging

# Генерация ключа Fernet (должен быть согласован между сервером и клиентом)
FERNET_KEY = b'k9XCkEDeTkFz8UDJZDnhTH8vMEEhk7Ep6MMj4c1mg24='  # Должно быть 32 байта
cipher = Fernet(FERNET_KEY)

def handle_client(client_socket, addr):
    logging.info(f"Новое подключение от {addr}")
    print(f"Подключение от {addr}")
    try:
        with client_socket:
            while True:
                # Получаем и расшифровываем заголовок
                encrypted_header = client_socket.recv(1024)
                if not encrypted_header:
                    print(f"Клиент {addr} отключился.")
                    break

                try:
                    header = cipher.decrypt(encrypted_header).decode()
                    print(f"Заголовок: {header}")
                except Exception as e:
                    print(f"Ошибка расшифровки заголовка от {addr}: {e}")
                    continue

                # Обработка текстового сообщения
                if header.startswith("TEXT:"):
                    encrypted_message = client_socket.recv(4096)
                    message = cipher.decrypt(encrypted_message).decode()
                    print(f"Сообщение от {addr}: {message}")
                    logging.info(f"Получено текстовое сообщение от {addr}: {message}")

                # Обработка файлов, изображений, папок и голосовых сообщений
                elif header.startswith(("FILE:", "IMAGE:", "FOLDER:", "VOICE:")):
                    filename = header.split(":", 1)[1]
                    file_type = (
                        "изображение" if header.startswith("IMAGE:")
                        else "папка" if header.startswith("FOLDER:")
                        else "голосовое сообщение" if header.startswith("VOICE:")
                        else "файл"
                    )
                    print(f"Получение {file_type} {filename} от {addr}")
                    logging.info(f"Получение {file_type} {filename} от {addr}")
                    # Получение и сохранение файла
                    with open(f"received_{filename}", "wb") as f:
                        while True:
                            encrypted_chunk = client_socket.recv(4096)
                            if not encrypted_chunk:
                                break
                            chunk = cipher.decrypt(encrypted_chunk)
                            if chunk == b"EOF":
                                print(f"{file_type.capitalize()} {filename} сохранено.")
                                break
                            f.write(chunk)

                    # Дополнительная обработка папок
                    if file_type == "папка" and filename.endswith(".zip"):
                        print(f"Распаковываем архив {filename}...")
                        with zipfile.ZipFile(f"received_{filename}", 'r') as zip_ref:
                            zip_ref.extractall(f"received_{filename}_extracted")
                        print(f"Архив {filename} распакован.")
                    
                    if file_type == "голосовое сообщение":
                        print(f"Получено голосовое сообщение: {filename}. Его можно воспроизвести с помощью аудиоплеера.")
                else:
                    print(f"Неизвестный заголовок от {addr}: {header}")

    except Exception as e:
        print(f"Ошибка с клиентом {addr}: {e}")
        logging.error(f"Ошибка с клиентом {addr}: {e}")
    finally:
        print(f"Соединение с {addr} закрыто.")
        logging.info(f"Соединение с {addr} закрыто.")
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 12345))
    server_socket.listen(5)

    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(certfile='bin/server.crt', keyfile='bin/server.key')

    print("Сервер запущен и ждёт соединений...")
    with context.wrap_socket(server_socket, server_side=True) as secure_socket:
        while True:
            client_socket, addr = secure_socket.accept()
            print(f"Подключение от {addr}")
            threading.Thread(target=handle_client, args=(client_socket, addr)).start()

if __name__ == "__main__":
    start_server()
