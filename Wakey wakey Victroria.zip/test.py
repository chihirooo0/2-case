import socket
import ssl
import threading
import os
import zipfile
import wave
import pyaudio
from cryptography.fernet import Fernet
import logging 

logging.basicConfig(
    filename="client_logs.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
# Использование того же ключа Fernet, что и на сервере
FERNET_KEY = b'k9XCkEDeTkFz8UDJZDnhTH8vMEEhk7Ep6MMj4c1mg24='  # Должно быть 32 байта
cipher = Fernet(FERNET_KEY)


def record_audio(output_file, record_seconds=5):
    """Функция записи голоса"""
    chunk = 1024
    format = pyaudio.paInt16
    channels = 1
    rate = 44100

    p = pyaudio.PyAudio()

    print("Запись началась...")
    stream = p.open(format=format, channels=channels,
                    rate=rate, input=True,
                    frames_per_buffer=chunk)
    frames = []

    for _ in range(0, int(rate / chunk * record_seconds)):
        data = stream.read(chunk)
        frames.append(data)

    print("Запись завершена.")

    stream.stop_stream()
    stream.close()
    p.terminate()

    with wave.open(output_file, 'wb') as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(p.get_sample_size(format))
        wf.setframerate(rate)
        wf.writeframes(b''.join(frames))
        logging.info(f"Голосовое сообщение сохранено в файл: {output_file}")

def zip_folder(folder_path, zip_filename):
    """Архивирование папки в ZIP"""
    folder_path = folder_path.strip('"')  # Убираем лишние кавычки
    if not os.path.exists(folder_path):
        logging.error(f"Папка {folder_path} не существует!")
        print(f"Папка {folder_path} не существует!")
        return
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(folder_path):
            for file in files:
                full_path = os.path.join(root, file)
                relative_path = os.path.relpath(full_path, folder_path)
                zipf.write(full_path, relative_path)
    logging.info(f"Папка {folder_path} архивирована в файл: {zip_filename}")

def send_file(secure_sock, filepath, file_type="FILE"):
    """Отправка файлов с шифрованием"""
    try:
        filepath = filepath.strip('"').strip("'")
        if not os.path.exists(filepath):
            logging.error(f"Файл {filepath} не найден.")
            print(f"Файл {filepath} не найден.")
            return

        filename = os.path.basename(filepath)
        # Отправка заголовка с типом файла
        header = f"{file_type}:{filename}".encode()
        secure_sock.sendall(cipher.encrypt(header))
        logging.info(f"Отправка загаловка {file_type.lower()}a: {filename}")
        # Если это папка, архивируем её в ZIP перед отправкой
        if os.path.isdir(filepath):
            zip_filename = f"{filename}.zip"
            zip_folder(filepath, zip_filename)
            filepath = zip_filename

        # Отправка самого файла
        with open(filepath, "rb") as f:
            while True:
                chunk = f.read(1024)
                if not chunk:
                    break  # Конец файла
                secure_sock.sendall(cipher.encrypt(chunk))  # Шифруем данные
        secure_sock.sendall(cipher.encrypt(b"EOF"))  # Отправка маркера конца файла
        logging.info(f"{file_type.capitalize()} {filename} успешно отправлено")
        print(f"{file_type.capitalize()} {filename} отправлено.")
    except Exception as e:
        logging.error(f"Ошибка при отправке {file_type.lower()}a: {e}")
        print(f"Ошибка при отправке {file_type.lower()}а: {e}")

def start_client():
    """Запуск клиента"""
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    context.load_verify_locations('bin/server.crt')

    with socket.create_connection(('localhost', 12345)) as sock:
        with context.wrap_socket(sock, server_hostname='localhost') as secure_sock:
            logging.info("Успешно подключено к серверу.")
            print("Подключено к серверу.")
            try:
                while True:
                    command = input("Введите команду (text, file, folder, image, voice, выход): ")
                    if command.lower() == "выход":
                        logging.info("Клиент завершает соединение")
                        print("Завершение соединения.")
                        break
                    elif command.lower() == "text":
                        message = input("Введите сообщение: ")
                        # Шифруем только данные, но не заголовок
                        encrypted_message = cipher.encrypt(f"TEXT:{message}".encode())
                        secure_sock.sendall(encrypted_message)
                        logging.info(f"Отправлено сообщение: {message}")
                    elif command.lower() == "file":
                        filepath = input("Введите путь к файлу: ")
                        send_file(secure_sock, filepath, file_type="FILE")
                    elif command.lower() == "folder":
                        folderpath = input("Введите путь к папке: ")
                        send_file(secure_sock, folderpath, file_type="FOLDER")
                    elif command.lower() == "image":
                        filepath = input("Введите путь к изображению: ")
                        send_file(secure_sock, filepath, file_type="IMAGE")
                    elif command.lower() == "voice":
                        output_file = "voice_message.wav"
                        record_seconds = int(input("Введите длительность записи (в секундах): "))
                        record_audio(output_file, record_seconds)
                        send_file(secure_sock, output_file, file_type="VOICE")
                    else:
                        logging.warning(f"Неизвестная команда: {command}")
                        print("Неизвестная команда.")
            except Exception as e:
                logging.error(f"Ошибка подключение: {e}")
                print(f"Ошибка: {e}")
            finally:
                secure_sock.shutdown(socket.SHUT_RDWR)
                secure_sock.close()
                logging.info("Соединение завершено.")
                print("Соединение завершено.")

if __name__ == "__main__":
    start_client()
